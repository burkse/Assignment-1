/*
 * This is the file in which you'll write a function to reverse a linked list.
 * Make sure to add your name and @oregonstate.edu email address below:
 *
 * Name:
 * Email:
 */

#include <stdio.h>

#include "list_reverse.h"

/*
 * In this function, you will be passed a pointer to the first node of a singly-linked list.
 * You should reverse the linked list and return the new "first" pointer.  The reversal
 * must be done in place, and you may not allocate any new memory in this
 * function.
 *
 * Params:
 *   first - a pointer to the first node of a singly-linked list to be reversed
 *
 * Return:
 *   Should return the new first of the reversed list.  If first is NULL, this
 *   function should return NULL.
 */
struct node* list_reverse(struct node* first) {
   if(first == NULL)
      return first;
   struct node *index_one;
   struct node *index_two;
   struct node *new_first;
   index_one = first;
   while(index_one->next != NULL)
   {
      index_one = index_one->next;
   }
   new_first = index_one;
   while(first->next != NULL)
   {
      index_one = first;
      while(index_one->next != NULL)
      {
	 index_two = index_one;
	 index_one = index_one->next;
      }
      index_one->next = index_two;
      index_two->next = NULL;
   }
  return new_first; 
}
